How to create VDS installer package with your Visual Studio
1) Open wvrcs.sln solution
2) Choose 'Release' from the Solution Configurations list box.
3) Execute 'Build Solution'
4) Move to 'bldtools3' folder
5) Right click on '99_unsgned_compo.ps1' and choose "Run with PowerShell".
6) Open wvrcs-installer.slln
7) Choose 'Release' from the Solution Configurations list box.
8) Execute 'Build Solution'
  You can find TosRCSetupFrontEnd.msi in 'FrontEnd\TosRCSetupFrontEnd\Release' folder 
  and TosRCSetupBackEnd.msi in 'BackEnd\TosRCSetupBackEnd\Release
